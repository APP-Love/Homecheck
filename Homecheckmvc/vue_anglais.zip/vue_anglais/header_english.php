
		<header>
			<div class="rectangle1">
				<div class="rectangle2">

					<a href="AProposDeHomeCheck.php" ><img class="logo" src="image/logo.png" alt="logo" /></a>
					<div class="texte1">
						<ul>
							<p class="Homecheck" > HomeCheck </p>
							<p class="Yourhouse" > Your house in your pocket </p>
						</ul>
					</div>
					<div id="Admin">
						<div><img class="PhotoAdmin" src="image/Msublime.jpg" alt="PhotoAdmin" /></div>
						<div class="barre" >  Jérémie <span class="nom"> SUBLIME </span></div>
						<a href="pageDaccueil.php" ><img class="deco" src="image/deconnexion.png" type="Déconnexion" alt="Disconnection"></a>
					</div>
					<div class="langues">
					<a href="?" > <img class="francais" src="image/francais.gif" type="Français" alt="Français" /></a>
					<a href="?" > <img class="anglais" src="image/anglais.gif"  type="Anglais" alt="English" /></a>
					</div>

				</div>
				<div class=" rectangle3">
					<table class="menu"> 
						<tr class="tr2">
							<td class="td2" onclick="location='AProposDeHomeCheck.php'" style="cursor:pointer" > About HomeCheck </td>
							<td class="td2" onclick="location= 'MesLogements.php'" style="cursor:pointer" > My
							accomodations </td>
							<td class="td2" onclick="location='MonProfil.php'" style="cursor:pointer">  My profil </td>
							<td class="td2" onclick="location='Contactez_nous.php'" style="cursor:pointer"> Contact us </td>
						</tr>
					</table>
						<form class="recherche" method="post" action="retour.php" >
							<label for=" Rechercher" ></label> 
							<input type="Search" name="Rechercher" id="Rechercher" placeholder="Search..."/>
							<input class="bouton" type="image" src="image/recherche.png" title="Search" />
						</form>

				</div>
			</div>
		</header>

