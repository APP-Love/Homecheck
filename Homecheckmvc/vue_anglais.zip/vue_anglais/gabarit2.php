<!DOCTYPE html>
<html>
    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <link rel="stylesheet" type="text/css" href="styles/POPUP.css" />
    <link rel="stylesheet" type="text/css" href="styles/SITE.css" />
    <link rel="stylesheet" type="text/css" href="styles/SITE2.css" />
        <title>
            Homecheck
        </title>
    </head>

    <body>
        
      <header>
         <?php echo($entete); ?>
      </header>
</hr>
 <?php echo($contenu); ?>   
</hr>
      <footer>
          
         Tout droits réservés@ 
    
      </footer>
    
</html>