
<footer> 
	<div>
		 All right reserved ©
	</div>
</footer>